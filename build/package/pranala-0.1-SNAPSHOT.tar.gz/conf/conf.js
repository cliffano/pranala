exports.conf = {
    "env": {
	    "dev": {
	        "appHost": "http://localhost:3000"
	    },
	    "prd": {
	        "appHost": "http://prn.la"
	    }
    }
}